﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;


namespace PBot.modules
{
    public class Misc : ModuleBase<SocketCommandContext>
    {
        [Command("donate")]
        public async Task Echo()
        {
            var embed = new EmbedBuilder();
            embed.WithTitle("$$");
            embed.WithDescription("Accepting Paypal");
            embed.WithColor(new Color(0, 255, 0));

            await Context.Channel.SendMessageAsync("", false, embed.Build());
        }

        [Command("falling down")]
        public async Task Best()
        {
            await Task.Delay(1500);
            await Context.Channel.SendMessageAsync("https://gyazo.com/3c54554bb9f49eb0454ed2e692920bca");
        }

        [Command("pokemon")]
        public async Task pokemon()
        {

            int randomNumber,shinyNumber;
            Random r = new Random();
            randomNumber = r.Next(0, 151); //0 151
            shinyNumber = r.Next(0, 5);

            var embed = new EmbedBuilder();
            embed.WithTitle(Context.User.Username + " Shiny: " + shinyNumber);
            embed.WithColor(new Color(0, 229, 255));

        //=====================Generation 1=========================
            if (randomNumber == 0)
            {
                embed.WithDescription("Bulbasaur! ID: " + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/bulbasaur.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/bulbasaur.gif");
            }
            if (randomNumber == 1)
            {
                embed.WithDescription("Ivysaur! ID: " + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/ivysaur.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/ivysaur.gif");
            }
            if (randomNumber == 2)
            {
                embed.WithDescription("Venusaur! ID: " + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/venusaur.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/venusaur.gif");
            }
            if (randomNumber == 3)
            {
                embed.WithDescription("Charmander! ID: " + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/charmander.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/charmander.gif");
            }
            if (randomNumber == 4)
            {
                embed.WithDescription("Charmeleon! ID: " + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/charmeleon.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/charmeleon.gif");
            }
            if (randomNumber == 5)
            {
                embed.WithDescription("Charizard! ID: " + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/charizard.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/charizard.gif");
            }
            if (randomNumber == 6)
            {
                embed.WithDescription("Squirtle! ID: " + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/squirtle.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/squirtle.gif");
            }
            if (randomNumber == 7)
            {
                embed.WithDescription("Wartortle! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/wartortle.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/wartortle.gif");
            }
            if (randomNumber == 8)
            {
                embed.WithDescription("Blastoise! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/blastoise.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/blastoise.gif");
            }
            if (randomNumber == 9)
            {
                embed.WithDescription("Caterpie! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/caterpie.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/caterpie.gif");
            }
            if (randomNumber == 10)
            {
                embed.WithDescription("Metapod! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/metapod.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/metapod.gif");
            }
            if (randomNumber == 11)
            {
                embed.WithDescription("Butterfree! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/butterfree.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/butterfree.gif");
            }
            if (randomNumber == 12)
            {
                embed.WithDescription("Weedle! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/weedle.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/weedle.gif");
            }
            if (randomNumber == 13)
            {
                embed.WithDescription("Kakuna! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/kakuna.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/kakuna.gif");
            }
            if (randomNumber == 14)
            {
                embed.WithDescription("Beedrill! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/beedrill.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/beedrill.gif");
            }
            if (randomNumber == 15)
            {
                embed.WithDescription("Pidgey! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/pidgey.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/pidgey.gif");
            }
            if (randomNumber == 16)
            {
                embed.WithDescription("Pidgeotto! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/pidgeotto.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/pidgeotto.gif");
            }
            if (randomNumber == 17)
            {
                embed.WithDescription("Pidgeot! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/pidgeot.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/pidgeot.gif");
            }
            if (randomNumber == 18)
            {
                embed.WithDescription("Rattata! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/rattata.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/rattata.gif");
            }
            if (randomNumber == 19)
            {
                embed.WithDescription("Raticate! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/raticate.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/raticate.gif");
            }
            if (randomNumber == 20)
            {
                embed.WithDescription("Spearow! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/spearow.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/spearow.gif");
            }
            if (randomNumber == 21)
            {
                embed.WithDescription("Fearow! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/fearow.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/fearow.gif");
            }
            if (randomNumber == 22)
            {
                embed.WithDescription("Ekans! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/ekans.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/ekans.gif");
            }
            if (randomNumber == 23)
            {
                embed.WithDescription("Arbok! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/arbok.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/arbok.gif");
            }
            if (randomNumber == 24)
            {
                embed.WithDescription("Pikachu! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/pikachu.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/pikachu.gif");
            }
            if (randomNumber == 25)
            {
                embed.WithDescription("Raichu! ID:" + randomNumber); ;
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/raichu.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/raichu.gif");
            }
            if (randomNumber == 26)
            {
                embed.WithDescription("Sandshrew! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/sandshrew.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/sandshrew.gif");
            }
            if (randomNumber == 27)
            {
                embed.WithDescription("Sandslash! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/sandslash.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/sandslash.gif");
            }
            if (randomNumber == 28)
            {
                embed.WithDescription("Nidoran♀! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/nidoran-f.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/nidoran_f.gif");
            }
            if (randomNumber == 29)
            {
                embed.WithDescription("Nidorina! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/nidorina.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/nidorina.gif");
            }
            if (randomNumber == 30)
            {
                embed.WithDescription("Nidoqueen! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/nidoqueen.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/nidoqueen.gif");
            }
            if (randomNumber == 31)
            {
                embed.WithDescription("Nidoran♂! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/nidoranm.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/nidoranm.gif");
            }
            if (randomNumber == 32)
            {
                embed.WithDescription("Nidorino! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/nidorino.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/nidorino.gif");
            }
            if (randomNumber == 33)
            {
                embed.WithDescription("Nidoking! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/nidoking.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/nidoking.gif");
            }
            if (randomNumber == 34)
            {
                embed.WithDescription("Clefairy! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/clefairy.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/clefairy.gif");

            }
            if (randomNumber == 35)
            {
                embed.WithDescription("Clefable! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/clefable.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/clefable.gif");
            }
            if (randomNumber == 36)
            {
                embed.WithDescription("Vulpix! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/vulpix.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/vulpix.gif");
            }
            if (randomNumber == 37)
            {
                embed.WithDescription("Ninetales! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/ninetales.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/ninetales.gif");
            }
            if (randomNumber == 38)
            {
                embed.WithDescription("Jigglypuff! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/jigglypuff.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/jigglypuff.gif");
            }
            if (randomNumber == 39)
            {
                embed.WithDescription("Wigglytuff! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/wigglytuff.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/wigglytuff.gif");
            }
            if (randomNumber == 40)
            {
                embed.WithDescription("Zubat! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/zubat.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/zubat.gif");
            }
            if (randomNumber == 41)
            {
                embed.WithDescription("Golbat! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/golbat.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/golbat.gif");
            }
            if (randomNumber == 42)
            {
                embed.WithDescription("Oddish! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/oddish.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/oddish.gif");
            }
            if (randomNumber == 43)
            {
                embed.WithDescription("Gloom! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/gloom.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/gloom.gif");
            }
            if (randomNumber == 44)
            {
                embed.WithDescription("Vileplume! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/vileplume.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/vileplume.gif");
            }
            if (randomNumber == 45)
            {
                embed.WithDescription("Paras! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/paras.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/paras.gif");
            }
            if (randomNumber == 46)
            {
                embed.WithDescription("Parasect! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/parasect.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/parasect.gif");
            }
            if (randomNumber == 47)
            {
                embed.WithDescription("Venonat! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/venonat.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/venonat.gif");
            }
            if (randomNumber == 48)
            {
                embed.WithDescription("Venomoth! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/venomoth.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/venomoth.gif");
            }
            if (randomNumber == 49)
            {
                embed.WithDescription("Diglett! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/diglett.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/diglett.gif");
            }
            if (randomNumber == 50)
            {
                embed.WithDescription("Dugtrio! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/dugtrio.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/dugtrio.gif");
            }
            if (randomNumber == 51)
            {
                embed.WithDescription("Meowth! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/meowth.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/meowth.gif");
            }
            if (randomNumber == 52)
            {
                embed.WithDescription("Persian! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/persian.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/persian.gif");
            }
            if (randomNumber == 53)
            {
                embed.WithDescription("Psyduck! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/psyduck.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/psyduck.gif");
            }
            if (randomNumber == 54)
            {
                embed.WithDescription("Golduck! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/golduck.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/golduck.gif");
            }
            if (randomNumber == 55)
            {
                embed.WithDescription("Mankey! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/mankey.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/mankey.gif");
            }
            if (randomNumber == 56)
            {
                embed.WithDescription("Primeape! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/primeape.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/primeape.gif");
            }
            if (randomNumber == 57)
            {
                embed.WithDescription("Growlithe! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/growlithe.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/growlithe.gif");
            }
            if (randomNumber == 58)
            {
                embed.WithDescription("Arcanine! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/arcanine.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/arcanine.gif");
            }
            if (randomNumber == 59)
            {
                embed.WithDescription("Poliwag! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/poliwag.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/poliwag.gif");
            }
            if (randomNumber == 60)
            {
                embed.WithDescription("Poliwhirl! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/poliwhirl.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/poliwhirl.gif");
            }
            if (randomNumber == 61)
            {
                embed.WithDescription("Poliwrath! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/poliwrath.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/poliwrath.gif");
            }
            if (randomNumber == 62)
            {
                embed.WithDescription("Abra! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/abra.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/abra.gif");
            }
            if (randomNumber == 63)
            {
                embed.WithDescription("Kadabra! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/kadabra.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/kadabra.gif");
            }
            if (randomNumber == 64)
            {
                embed.WithDescription("Alakazam! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/alakazam.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/alakazam.gif");
            }
            if (randomNumber == 65)
            {
                embed.WithDescription("Machop! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/machop.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/machop.gif");
            }
            if (randomNumber == 66)
            {
                embed.WithDescription("Machoke! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/machoke.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/machoke.gif");
            }
            if (randomNumber == 67)
            {
                embed.WithDescription("Machamp! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/machamp.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/machamp.gif");
            }
            if (randomNumber == 68)
            {
                embed.WithDescription("Bellsprout! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/bellsprout.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/bellsprout.gif");
            }
            if (randomNumber == 69)
            {
                embed.WithDescription("Weepinbell! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/weepinbell.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/weepinbell.gif");
            }
            if (randomNumber == 70)
            {
                embed.WithDescription("Victreebel! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/victreebel.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/victreebel.gif");
            }
            if (randomNumber == 71)
            {
                embed.WithDescription("Tentacool! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/tentacool.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/tentacool.gif");
            }
            if (randomNumber == 72)
            {
                embed.WithDescription("Tentacruel! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/tentacruel.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/tentacruel.gif");
            }
            if (randomNumber == 73)
            {
                embed.WithDescription("Geodude! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/geodude.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/geodude.gif");
            }
            if (randomNumber == 74)
            {
                embed.WithDescription("Graveler! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/graveler.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/graveler.gif");
            }
            if (randomNumber == 75)
            {
                embed.WithDescription("Golem! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/golem.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/golem.gif");
            }
            if (randomNumber == 76)
            {
                embed.WithDescription("Ponyta! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/ponyta.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/ponyta.gif");
            }
            if (randomNumber == 77)
            {
                embed.WithDescription("Rapidash! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/rapidash.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/rapidash.gif");
            }
            if (randomNumber == 78)
            {
                embed.WithDescription("Slowpoke! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/slowpoke.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/slowpoke.gif");
            }
            if (randomNumber == 79)
            {
                embed.WithDescription("Slowbro! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/slowbro.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/slowbro.gif");
            }
            if (randomNumber == 80)
            {
                embed.WithDescription("Magnemite! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/magnemite.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/magnemite.gif");
            }
            if (randomNumber == 81)
            {
                embed.WithDescription("Magneton! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/magneton.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/magneton.gif");
            }
            if (randomNumber == 82)
            {
                embed.WithDescription("Farfetch'd! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/farfetchd.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/farfetchd.gif");
            }
            if (randomNumber == 83)
            {
                embed.WithDescription("Doduo! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/doduo.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/doduo.gif");
            }
            if (randomNumber == 84)
            {
                embed.WithDescription("Dodrio! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/dodrio.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/dodrio.gif");
            }
            if (randomNumber == 85)
            {
                embed.WithDescription("Seel! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/seel.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/seel.gif");
            }
            if (randomNumber == 86)
            {
                embed.WithDescription("Dewgong! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/dewgong.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/dewgong.gif");
            }
            if (randomNumber == 87)
            {
                embed.WithDescription("Grimer! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/grimer.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/grimer.gif");
            }
            if (randomNumber == 88)
            {
                embed.WithDescription("Muk! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/muk.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/muk.gif");
            }
            if (randomNumber == 89)
            {
                embed.WithDescription("Shellder! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/shellder.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/shellder.gif");
            }
            if (randomNumber == 90)
            {
                embed.WithDescription("Cloyster! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/cloyster.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/cloyster.gif");
            }
            if (randomNumber == 91)
            {
                embed.WithDescription("Gastly! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/gastly.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/gastly.gif");
            }
            if (randomNumber == 92)
            {
                embed.WithDescription("Haunter! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/haunter.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/haunter.gif");
            }
            if (randomNumber == 93)
            {
                embed.WithDescription("Gengar! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/gengar.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/gengar.gif");
            }
            if (randomNumber == 94)
            {
                embed.WithDescription("Onix! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/onix.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/onix.gif");
            }
            if (randomNumber == 95)
            {
                embed.WithDescription("Drowzee! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/drowzee.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/drowzee.gif");
            }
            if (randomNumber == 96)
            {
                embed.WithDescription("Hypno! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/hypno.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/hypno.gif");
            }
            if (randomNumber == 97)
            {
                embed.WithDescription("Krabby! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/krabby.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/krabby.gif");
            }
            if (randomNumber == 98)
            {
                embed.WithDescription("Kingler! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/kingler.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/kingler.gif");
            }
            if (randomNumber == 99)
            {
                embed.WithDescription("Voltorb! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/voltorb.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/voltorb.gif");
            }
            if (randomNumber == 100)
            {
                embed.WithDescription("Electrode! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/electrode.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/electrode.gif");
            }
            if (randomNumber == 101)
            {
                embed.WithDescription("Exeggcute! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/exeggcute.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/exeggcute.gif");
            }
            if (randomNumber == 102)
            {
                embed.WithDescription("Exeggutor! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/exeggutor.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/exeggutor.gif");
            }
            if (randomNumber == 103)
            {
                embed.WithDescription("Cubone! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/cubone.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/cubone.gif");
            }
            if (randomNumber == 104)
            {
                embed.WithDescription("Marowak! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/marowak.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/marowak.gif");
            }
            if (randomNumber == 105)
            {
                embed.WithDescription("Hitmonlee! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/hitmonlee.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/hitmonlee.gif");
            }
            if (randomNumber == 106)
            {
                embed.WithDescription("Hitmonchan! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/hitmonchan.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/hitmonchan.gif");
            }
            if (randomNumber == 107)
            {
                embed.WithDescription("Lickitung! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/lickitung.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/lickitung.gif");
            }
            if (randomNumber == 108)
            {
                embed.WithDescription("Koffing! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/koffing.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/koffing.gif");
            }
            if (randomNumber == 109)
            {
                embed.WithDescription("Weezing! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/weezing.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/weezing.gif");
            }
            if (randomNumber == 110)
            {
                embed.WithDescription("Rhyhorn! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/rhyhorn.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/rhyhorn.gif");
            }
            if (randomNumber == 111)
            {
                embed.WithDescription("Rhydon! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/rhydon.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/rhydon.gif");
            }
            if (randomNumber == 112)
            {
                embed.WithDescription("Chansey! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/chansey.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/chansey.gif");
            }
            if (randomNumber == 113)
            {
                embed.WithDescription("Tangela! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/tangela.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/tangela.gif");
            }
            if (randomNumber == 114)
            {
                embed.WithDescription("Kangaskhan! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/kangaskhan.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/kangaskhan.gif");
            }
            if (randomNumber == 115)
            {
                embed.WithDescription("Horsea! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/horsea.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/horsea.gif");
            }
            if (randomNumber == 116)
            {
                embed.WithDescription("Seadra! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/seadra.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/seadra.gif");
            }
            if (randomNumber == 117)
            {
                embed.WithDescription("Goldeen! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/goldeen.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/goldeen.gif");
            }
            if (randomNumber == 118)
            {
                embed.WithDescription("Seaking! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/seaking.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/seaking.gif");
            }
            if (randomNumber == 119)
            {
                embed.WithDescription("Staryu! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/staryu.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/staryu.gif");
            }
            if (randomNumber == 120)
            {
                embed.WithDescription("Starmie! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/starmie.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/starmie.gif");
            }
            if (randomNumber == 121)
            {
                embed.WithDescription("Mr.Mime! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/mrmime.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/mrmime.gif");
            }
            if (randomNumber == 122)
            {
                embed.WithDescription("Scyther! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/scyther.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/scyther.gif");
            }
            if (randomNumber == 123)
            {
                embed.WithDescription("Jynx! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/jynx.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/jynx.gif");
            }
            if (randomNumber == 124)
            {
                embed.WithDescription("Electabuzz! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/electabuzz.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/electabuzz.gif");
            }
            if (randomNumber == 125)
            {
                embed.WithDescription("Magmar! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/magmar.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/magmar.gif");
            }
            if (randomNumber == 126)
            {
                embed.WithDescription("Pinsir! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/pinsir.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/pinsir.gif");
            }
            if (randomNumber == 127)
            {
                embed.WithDescription("Tauros! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/tauros.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/tauros.gif");
            }
            if (randomNumber == 128)
            {
                embed.WithDescription("Magikarp! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/magikarp.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/magikarp.gif");
            }
            if (randomNumber == 129)
            {
                embed.WithDescription("Gyarados! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/gyarados.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/gyarados.gif");
            }
            if (randomNumber == 130)
            {
                embed.WithDescription("Lapras! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/lapras.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/lapras.gif");
            }
            if (randomNumber == 131)
            {
                embed.WithDescription("Ditto! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/ditto.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/ditto.gif");
            }
            if (randomNumber == 132)
            {
                embed.WithDescription("Eevee! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/eevee.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/eevee.gif");
            }
            if (randomNumber == 133)
            {
                embed.WithDescription("Vaporeon! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/vaporeon.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/vaporeon.gif");
            }
            if (randomNumber == 134)
            {
                embed.WithDescription("Jolteon! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/jolteon.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/jolteon.gif");
            }
            if (randomNumber == 135)
            {
                embed.WithDescription("Flareon! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/flareon.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/flareon.gif");
            }
            if (randomNumber == 136)
            {
                embed.WithDescription("Porygon! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/porygon.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/porygon.gif");
            }
            if (randomNumber == 137)
            {
                embed.WithDescription("Omanyte! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/omanyte.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/omanyte.gif");
            }
            if (randomNumber == 138)
            {
                embed.WithDescription("Omastar! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/omastar.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/omastar.gif");
            }
            if (randomNumber == 139)
            {
                embed.WithDescription("Kabuto! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/kabuto.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/kabuto.gif");
            }
            if (randomNumber == 140)
            {
                embed.WithDescription("Kabutops! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/kabutops.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/kabutops.gif");
            }
            if (randomNumber == 141)
            {
                embed.WithDescription("Aerodactyl! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/aerodactyl.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/aerodactyl.gif");
            }
            if (randomNumber == 142)
            {
                embed.WithDescription("Snorlax! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/snorlax.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/snorlax.gif");
            }
            if (randomNumber == 143)
            {
                embed.WithDescription("Articuno! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/articuno.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/articuno.gif");
            }
            if (randomNumber == 144)
            {
                embed.WithDescription("Zapdos! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/zapdos.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/zapdos.gif");
            }
            if (randomNumber == 145)
            {
                embed.WithDescription("Moltres! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/moltres.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/moltres.gif");
            }
            if (randomNumber == 146)
            {
                embed.WithDescription("Dratini! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/dratini.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/dratini.gif");
            }
            if (randomNumber == 147)
            {
                embed.WithDescription("Dragonair! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/dragonair.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/dragonair.gif");
            }
            if (randomNumber == 148)
            {
                embed.WithDescription("Dragonite! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/dragonite.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/dragonite.gif");
            }
            if (randomNumber == 149)
            {
                embed.WithDescription("Mewtwo! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/mewtwo.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/mewtwo.gif");
            }
            if (randomNumber == 150)
            {
                embed.WithDescription("Mew! ID:" + randomNumber);
                if (shinyNumber > 0)
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani/mew.gif");
                else
                    embed.WithImageUrl("https://play.pokemonshowdown.com/sprites/xyani-shiny/mew.gif");
            }
         
            await Context.Channel.SendMessageAsync("", false, embed.Build());

        }
    }
}
